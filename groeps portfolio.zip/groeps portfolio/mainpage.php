<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mainpage</title>
    <link rel="stylesheet" href="mainpage.css">
</head>
<body>

<div class="menu-container">
    <div class="balk"></div>

    <div class="groepsnaam"><h1>L.M.M.S.</h1></div>
    <div class="functie"><h1>Developers</h1></div>


<div class="buttons-container">
    <a href="mainpage.php" class="homepage-btn">Homepage</a>
    <a href="projects.php" class="projects-btn">Projects</a>
    <a href="team.php" class="team-btn">Our team</a>
    <a href="contact.php" class="contact-btn">Contact us</a>
    </div>
</div>


    
</body>
</html>